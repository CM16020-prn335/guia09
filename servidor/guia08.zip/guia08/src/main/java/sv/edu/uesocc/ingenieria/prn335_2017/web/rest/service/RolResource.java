/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.rest.service;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import static javax.ws.rs.HttpMethod.PUT;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import sv.edu.uesocc.ingenieria.sv.prn335_2017.datos.accseso.RolFacadeLocal;
import sv.edu.uesocc.ingenieria.sv.prn335_2017.datos.definiciones.Rol;

/**
 *
 * @author kevin
 */
@Path("rol")
public class RolResource implements Serializable{
    
    @EJB
     RolFacadeLocal  rolFacade;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Rol> findAll( ) {
      
        try {
            if (rolFacade != null) {
                return rolFacade.findAll( );
            } 
        } catch (Exception e) {
             Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        }
        return Collections.EMPTY_LIST;
    }
    
     @GET
    @Path("{first}/{tamanio}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Rol> findRange(
            @PathParam("first") @DefaultValue("0") int first,
            @PathParam("tamanio") @DefaultValue("10") int size) {
        try {
            if (rolFacade != null) {
                return rolFacade.findRange(first, size);
            }
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        }
        return Collections.EMPTY_LIST;
    }
    
    @GET
    @Path("{idrol}")
    @Produces(MediaType.APPLICATION_JSON)
    public Rol findById(
            @PathParam("idrol") Integer id){
        try {
            if (rolFacade != null && id != null) {
               
                return rolFacade.find(id);
                
            } else {
                
            }
        } catch (Exception e) {
             Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        }
        
      return new Rol();
   }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Rol crear(Rol nuevo){
        if (nuevo != null && nuevo.getIdRol() == null) {
            try {
                if (rolFacade != null) {
                    Rol respuesta = rolFacade.crear(nuevo);
                    if (respuesta!=null) {
                        return respuesta;
                    }
                }
            } catch (Exception e) {
                 Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
            }
        }
     return new Rol();
    }
    
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    public Rol editar(Rol nuevo){
        if (nuevo != null ) {
            try {
                if (rolFacade != null) {
                    Rol respuesta = rolFacade.edit(nuevo);
                    if (respuesta!=null) {
                        return respuesta;
                    }
                }
            } catch (Exception e) {
                 Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
            }
        }
     return new Rol();
    }
}
