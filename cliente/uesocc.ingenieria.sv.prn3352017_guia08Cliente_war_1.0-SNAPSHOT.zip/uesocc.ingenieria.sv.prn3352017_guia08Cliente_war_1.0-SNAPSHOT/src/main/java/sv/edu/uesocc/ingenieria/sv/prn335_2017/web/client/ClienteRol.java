/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.sv.prn335_2017.web.client;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import sv.edu.uesocc.ingenieria.sv.prn335_2017.datos.definiciones.Rol;

/**
 *
 * @author kevin
 */
public class ClienteRol implements Serializable {

    private WebTarget target;
    private Client cliente;
    private List<Rol> salida;
    private String rolMatch;
    private Rol rol = new Rol();

    public ClienteRol() {
        try {
            cliente = ClientBuilder.newClient();
            target = cliente.target("http://localhost:8080/guia08-1.0-SNAPSHOT/webresources/rol");
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        }
    }

    public List filtro() {
        salida = null;
        try {
            salida = target.request(MediaType.APPLICATION_JSON).get(new GenericType<List<Rol>>() {
            });

        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        } finally {
            if (salida == null) {
                salida = Collections.EMPTY_LIST;
                System.out.println(" hola");
            }
        }
        return salida;
    }

    public Rol crear(Rol rol1) {
        if (cliente != null) {
            Rol salida1 = target.request(MediaType.APPLICATION_JSON).post(Entity.entity(rol1, MediaType.APPLICATION_JSON), Rol.class);
            filtro();
            if (salida1 != null && salida1.getIdRol() == null) {
                return salida1;
            }
        }
        return null;
    }
    
      public Rol editar(Rol rol1) {
        if (cliente != null) {
            Rol salida1 = target.request(MediaType.APPLICATION_JSON).put(Entity.entity(rol1, MediaType.APPLICATION_JSON), Rol.class);
            filtro();
            if (salida1 != null ) {
                return salida1;
            }
        }
        return null;
    }

    public List<Rol> getSalida() {
        return salida;
    }

    public void setSalida(List<Rol> salida) {
        this.salida = salida;
    }

    public String getRolMatch() {
        return rolMatch;
    }

    public void setRolMatch(String rolMatch) {
        this.rolMatch = rolMatch;
    }

}
