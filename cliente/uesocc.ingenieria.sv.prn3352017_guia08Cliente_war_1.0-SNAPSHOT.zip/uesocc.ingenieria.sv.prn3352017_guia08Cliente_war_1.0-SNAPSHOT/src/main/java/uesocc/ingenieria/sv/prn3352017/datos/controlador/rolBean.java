/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uesocc.ingenieria.sv.prn3352017.datos.controlador;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.primefaces.event.SelectEvent;
import sv.edu.uesocc.ingenieria.sv.prn335_2017.datos.definiciones.Rol;
import sv.edu.uesocc.ingenieria.sv.prn335_2017.web.client.ClienteRol;

@Named(value = "rolBean")
@ViewScoped
public class rolBean extends ClienteRol  implements Serializable {

   
    Rol rol= new Rol();
    boolean activo=false, panel = true;
    List listaRegistros = getSalida();
    public rolBean() {
    }
   
    /**
     * Este metodo carga la lista inicial de datos a la DataTable al ingresar a
     * la aplicacion
     */
    @PostConstruct
    public void init() {
       filtro();
    }

     public void agregar() {
        crear(rol);
        cancelar();
     }
     
     public void modificar() {
        editar(rol);
        cancelar();
     }
     public  void delete(){
         eliminar(rol);
         cancelar();
     }


    /**
     * si el objeto rol es diferente de nulo asigna una nueva instancia a este
     * para dejarlo vacio, oculta el panel de botones de edicion
     */
    public void cancelar() {
        rol=new Rol();
        System.out.println("LIMPIAR");
        panel = true;
        activo=false;
    }
    

    /**
     * Recice un evente de tipo SelectEvent, asigna los valores del objeto
     * recivido a las propiedades del objeto rol
     *
     * @param event
     */
    public void onRowSelect(SelectEvent event) {
        rol = (Rol) event.getObject();
        panel=false;
        activo=true;
    }


    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }


    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public boolean isPanel() {
        return panel;
    }

    public void setPanel(boolean panel) {
        this.panel = panel;
    }

    public List<Rol> getListaRegistros() {
        return listaRegistros;
    }

    public void setListaRegistros(List<Rol> listaRegistros) {
        this.listaRegistros = listaRegistros;
    }
    

}
